export default {
  logoUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/88517310/YlwphyxtpQlZcsvp.svg",
};
