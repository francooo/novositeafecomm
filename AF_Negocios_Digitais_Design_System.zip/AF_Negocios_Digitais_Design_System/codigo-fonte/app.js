const PHONE_DISPLAY = '(51) 98122-0279';
const PHONE_LINK = '+5551981220279';
const EMAIL = 'contato@afecomm.com.br';
const WA_URL = `https://wa.me/${PHONE_LINK}`;

const servicePages = {
  '/servicos/consultoria': {
    title: 'Consultoria em e-commerce',
    eyebrow: 'Estratégia para crescer com clareza',
    subtitle: 'Transforme seu negócio digital com estratégia',
    description: 'Consultoria estratégica e personalizada para identificar oportunidades, corrigir gargalos e potencializar resultados.',
    icon: 'compass',
    benefits: ['Diagnóstico completo do e-commerce', 'Plano de ação personalizado', 'Acompanhamento e mentoria'],
    includes: ['Análise técnica e operacional', 'Roadmap de prioridades', 'Reuniões periódicas', 'Suporte de especialistas'],
    process: [
      ['Mapeamento', 'Análise detalhada do cenário atual e identificação de oportunidades.'],
      ['Desenvolvimento', 'Elaboração do plano de ação e definição de estratégias.'],
      ['Implementação', 'Acompanhamento e ajustes contínuos para garantir resultados.'],
    ],
  },
  '/servicos/desenvolvimento': {
    title: 'Desenvolvimento de e-commerce',
    eyebrow: 'Lojas virtuais e plataformas',
    subtitle: 'Lojas virtuais modernas e escaláveis',
    description: 'Desenvolvimento de lojas virtuais sob medida, seguras e otimizadas para performance e conversão.',
    icon: 'store',
    benefits: ['Design responsivo e exclusivo', 'Integração de pagamentos', 'SEO otimizado'],
    includes: ['Briefing e planejamento', 'Desenvolvimento ágil', 'Testes e homologação', 'Suporte pós-lançamento'],
    process: [
      ['Mapeamento', 'Entendimento do público, objetivos e diferenciais.'],
      ['Desenvolvimento', 'Criação da loja virtual com tecnologia de ponta.'],
      ['Implementação', 'Publicação, testes finais e suporte contínuo.'],
    ],
    partners: ['Nuvemshop — parceiro certificado', 'Linx Commerce', 'Uappi'],
    related: ['/servicos/desenvolvimento/nuvemshop'],
  },
  '/servicos/ia': {
    title: 'Sistemas com Inteligência Artificial',
    eyebrow: 'IA aplicada ao negócio real',
    subtitle: 'Automatize e personalize com inteligência',
    description: 'Soluções de IA sob medida para automação, personalização e decisões inteligentes.',
    icon: 'sparkles',
    benefits: ['Chatbots inteligentes', 'Recomendações personalizadas', 'Análise preditiva'],
    includes: ['Desenvolvimento de modelos IA', 'Integração com sistemas', 'Treinamento e suporte'],
    process: [
      ['Mapeamento', 'Identificação de oportunidades para IA no seu negócio.'],
      ['Desenvolvimento', 'Criação e treinamento de modelos inteligentes.'],
      ['Implementação', 'Integração e acompanhamento dos resultados.'],
    ],
  },
  '/servicos/bi': {
    title: 'Business Intelligence (BI)',
    eyebrow: 'Dados para decidir melhor',
    subtitle: 'Transforme dados em decisões',
    description: 'Soluções de BI com dashboards, relatórios e análises para impulsionar o crescimento.',
    icon: 'chart',
    benefits: ['Dashboards interativos', 'Relatórios automatizados', 'KPIs personalizados'],
    includes: ['Mapeamento de indicadores', 'Desenvolvimento de painéis', 'Treinamento de equipe'],
    process: [
      ['Mapeamento', 'Levantamento de necessidades e indicadores.'],
      ['Desenvolvimento', 'Criação de dashboards e relatórios.'],
      ['Implementação', 'Treinamento e acompanhamento dos resultados.'],
    ],
  },
  '/servicos/automacao': {
    title: 'Automação de Processos',
    eyebrow: 'Mais eficiência na operação',
    subtitle: 'Eficiência e redução de custos',
    description: 'Automatize tarefas repetitivas e aumente a eficiência do seu negócio com automação inteligente.',
    icon: 'workflow',
    benefits: ['Mapeamento de processos', 'Desenvolvimento de integrações', 'Workflows automatizados'],
    includes: ['Análise de gargalos', 'Criação de fluxos', 'Monitoramento e alertas'],
    process: [
      ['Mapeamento', 'Identificação de gargalos e oportunidades.'],
      ['Desenvolvimento', 'Criação de integrações e automações.'],
      ['Implementação', 'Monitoramento e suporte contínuo.'],
    ],
  },
  '/servicos/sites': {
    title: 'Sites Institucionais',
    eyebrow: 'Presença digital profissional',
    subtitle: 'Uma presença digital forte e profissional',
    description: 'Desenvolvimento de sites institucionais modernos, responsivos e otimizados para resultados.',
    icon: 'window',
    benefits: ['Design exclusivo', 'Responsividade total', 'SEO avançado'],
    includes: ['Layout personalizado', 'CMS integrado', 'Otimização de performance'],
    process: [
      ['Mapeamento', 'Levantamento de requisitos e identidade visual.'],
      ['Desenvolvimento', 'Criação do site com foco em performance.'],
      ['Implementação', 'Publicação e otimização para SEO.'],
    ],
  },
  '/servicos/trafego': {
    title: 'Gestão de Tráfego Pago',
    eyebrow: 'Growth & performance',
    subtitle: 'Atraia mais clientes e vendas',
    description: 'Campanhas estratégicas em Google Ads, Facebook Ads e outras plataformas para maximizar resultados.',
    icon: 'megaphone',
    benefits: ['Planejamento de campanhas', 'Criação de anúncios', 'Otimização de investimento'],
    includes: ['Gestão de contas', 'Relatórios de performance', 'Remarketing'],
    process: [
      ['Mapeamento', 'Análise do público e definição de objetivos.'],
      ['Desenvolvimento', 'Criação e otimização das campanhas.'],
      ['Implementação', 'Acompanhamento e ajustes para maximizar ROI.'],
    ],
  },
  '/servicos/erp': {
    title: 'Implementação de ERPs',
    eyebrow: 'Sistemas e gestão conectados',
    subtitle: 'Centralize e automatize sua gestão',
    description: 'Implementação de sistemas ERP sob medida para automatizar processos e centralizar a gestão.',
    icon: 'database',
    benefits: ['Diagnóstico e planejamento', 'Parametrização e customização', 'Integração de sistemas'],
    includes: ['Treinamento da equipe', 'Suporte pós-implantação', 'Acompanhamento contínuo'],
    process: [
      ['Mapeamento', 'Entendimento das necessidades e processos.'],
      ['Desenvolvimento', 'Parametrização e integração do ERP.'],
      ['Implementação', 'Treinamento e suporte pós-implantação.'],
    ],
    partners: ['Olist ERP Tiny — parceiro certificado'],
  },
  '/servicos/integracao': {
    title: 'Integração de Sistemas',
    eyebrow: 'Sua operação em sintonia',
    subtitle: 'Conecte todas as áreas do seu negócio',
    description: 'Integrações inteligentes entre plataformas, ERPs, e-commerces e APIs.',
    icon: 'plug',
    benefits: ['Mapeamento de necessidades', 'Desenvolvimento de APIs', 'Sincronização de dados'],
    includes: ['Monitoramento 24/7', 'Documentação completa', 'Suporte técnico'],
    process: [
      ['Mapeamento', 'Identificação dos sistemas e fluxos a integrar.'],
      ['Desenvolvimento', 'Criação de APIs e conectores sob medida.'],
      ['Implementação', 'Monitoramento, documentação e suporte.'],
    ],
  },
};

const serviceOrder = [
  '/servicos/consultoria',
  '/servicos/desenvolvimento',
  '/servicos/ia',
  '/servicos/bi',
  '/servicos/automacao',
  '/servicos/sites',
  '/servicos/trafego',
  '/servicos/erp',
  '/servicos/integracao',
];

const faqs = [
  {
    question: 'Em quanto tempo vejo resultados?',
    answer: 'Depende do serviço. Em consultoria, as primeiras recomendações chegam em até 2 semanas. Em desenvolvimento, o primeiro MVP fica pronto em 4 a 8 semanas. Para resultados de tráfego e conversão, os primeiros números aparecem em 30 a 60 dias de operação.',
  },
  {
    question: 'Trabalham com qual porte de empresa?',
    answer: 'Atendemos desde empreendedores que estão montando sua primeira loja até empresas com operações de médio e grande porte. O que importa é a vontade de crescer com estratégia — e não apenas ferramentas.',
  },
  {
    question: 'Posso contratar só um serviço?',
    answer: 'Sim. Você pode contratar consultoria pontual, um projeto de desenvolvimento específico ou uma automação isolada. Não há obrigação de pacotes fechados — o escopo é montado de acordo com a necessidade.',
  },
  {
    question: 'Quais plataformas vocês dominam?',
    answer: 'Shopify, WooCommerce, VTEX, Nuvemshop, Magento e plataformas customizadas. Também há integrações com marketplaces como Mercado Livre, Amazon, Shopee e Magazine Luiza, conforme o conteúdo publicado no site de referência.',
  },
  {
    question: 'Como funciona o suporte pós-entrega?',
    answer: 'O site de referência informa planos de suporte contínuo com SLA definido, horas mensais de manutenção e evolução ou suporte avulso. O atendimento pode ocorrer via WhatsApp, e-mail e sistema de tickets.',
  },
];

const testimonials = [
  {
    quote: 'O depoimento relata que, em 90 dias, a taxa de conversão dobrou e o custo por aquisição caiu 40% após a entrega do novo site.',
    name: 'Ricardo Santos',
    role: 'CEO · Loja Exclusiva',
  },
  {
    quote: 'O depoimento atribui à automação com IA a redução de 35% nos custos operacionais e destaca a combinação entre tecnologia e visão de negócio.',
    name: 'Camila Mendes',
    role: 'Diretora de Ops · ModaPlus',
  },
  {
    quote: 'O relato descreve a migração completa do ERP integrado ao Shopify sem uma hora de indisponibilidade e destaca o cuidado com a execução.',
    name: 'Pedro Lima',
    role: 'CTO · TechStore Brasil',
  },
];

const processSteps = [
  ['01', 'Diagnóstico', 'Analisamos fundo o seu negócio: métricas, tecnologia, concorrência e oportunidades para montar um diagnóstico preciso.'],
  ['02', 'Estratégia', 'Desenhamos o plano de ação com prioridades, entregáveis, timelines e KPIs claros — sem achismo.'],
  ['03', 'Execução', 'Desenvolvimento, integrações, automações e ajustes acontecem com transparência.'],
  ['04', 'Evolução contínua', 'Monitoramos, medimos e evoluímos com relatórios periódicos e otimizações constantes.'],
];

const icons = {
  compass: '<circle cx="12" cy="12" r="9"/><path d="m16.2 7.8-2.8 5.6-5.6 2.8 2.8-5.6 5.6-2.8Z"/>',
  store: '<path d="M3 10.5 4.5 4h15l1.5 6.5"/><path d="M4 10v9h16v-9M3 10a2 2 0 0 0 4 0 2 2 0 0 0 4 0 2 2 0 0 0 4 0 2 2 0 0 0 4 0 2 2 0 0 0 4 0M9 19v-5h6v5"/>',
  sparkles: '<path d="m12 3 1.6 5.4L19 10l-5.4 1.6L12 17l-1.6-5.4L5 10l5.4-1.6L12 3Z"/><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15ZM5 3l.7 1.8L7.5 5.5l-1.8.7L5 8l-.7-1.8-1.8-.7 1.8-.7L5 3Z"/>',
  chart: '<path d="M3 3v18h18"/><path d="m7 14 4-4 3 3 6-7"/><path d="M16 6h4v4"/>',
  workflow: '<rect x="3" y="4" width="6" height="5" rx="1"/><rect x="15" y="4" width="6" height="5" rx="1"/><rect x="9" y="16" width="6" height="5" rx="1"/><path d="M6 9v3h12V9M12 12v4"/>',
  window: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 9h18M7 6.5h.01M10 6.5h.01M8 14h8M8 17h5"/>',
  megaphone: '<path d="m3 11 18-5v12L3 13v-2Z"/><path d="M11 15.2 13 21h-4l-1.5-6.5M21 10a3 3 0 0 1 0 4"/>',
  database: '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
  plug: '<path d="M8 2v6M16 2v6M6 8h12v2a6 6 0 0 1-6 6v6M8 8v2a4 4 0 0 0 8 0V8"/>',
  arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  leaf: '<path d="M20 4c-8 0-14 3-14 10a6 6 0 0 0 6 6c7 0 8-8 8-16Z"/><path d="M4 21c3-5 7-8 12-11"/>',
  hand: '<path d="M8 12V6a1.5 1.5 0 0 1 3 0v5-7a1.5 1.5 0 0 1 3 0v7-5a1.5 1.5 0 0 1 3 0v6-3a1.5 1.5 0 0 1 3 0v5c0 5-3 8-7 8h-1c-3 0-5-1.5-7-4l-2-3a1.5 1.5 0 0 1 2.5-1.6L8 15"/>',
  heart: '<path d="M20.8 8.6c0 5.4-8.8 11-8.8 11S3.2 14 3.2 8.6A4.6 4.6 0 0 1 12 6.3a4.6 4.6 0 0 1 8.8 2.3Z"/>',
  message: '<path d="M21 11.5a8.5 8.5 0 0 1-9 8.5 9.5 9.5 0 0 1-4-.9L3 21l1.7-4.3A8 8 0 0 1 3 11.5 8.5 8.5 0 0 1 12 3a8.5 8.5 0 0 1 9 8.5Z"/>',
};

function icon(name, className = '') {
  return `<svg class="icon ${className}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.sparkles}</svg>`;
}

function link(path, label, className = '', extra = '') {
  return `<a class="${className}" href="${path}" data-link ${extra}>${label}</a>`;
}

function cta(text = 'Conte seu desafio', className = 'button button-primary') {
  return link('/contato', `${text} ${icon('arrow')}`, className);
}

function header() {
  return `
    <header class="site-header">
      <div class="header-inner">
        ${link('/', '<span class="brand-mark">AF</span><span class="brand-name">AF <b>Negócios Digitais</b></span>', 'brand-lockup', 'aria-label="AF Negócios Digitais — início"')}
        <button class="mobile-toggle" type="button" aria-label="Abrir menu" aria-expanded="false" data-menu-toggle><span></span><span></span></button>
        <nav class="main-nav" aria-label="Navegação principal" data-main-nav>
          <details class="nav-services">
            <summary>Soluções <span class="chevron">⌄</span></summary>
            <div class="services-menu">
              <div class="menu-intro"><span class="eyebrow">Soluções para sua operação</span><p>Estratégia, tecnologia e acompanhamento para cada etapa do e-commerce.</p></div>
              <div class="menu-links">${serviceOrder.map((route) => link(route, `${icon(servicePages[route].icon)}<span>${servicePages[route].title}</span>`, 'menu-link')).join('')}${link('/servicos/desenvolvimento/nuvemshop', `${icon('store')}<span>Nuvemshop</span>`, 'menu-link')}</div>
            </div>
          </details>
          ${link('/sobre', 'Quem somos', 'nav-link')}
          ${link('/processo', 'Nosso processo', 'nav-link')}
          ${link('/cases', 'Histórias', 'nav-link')}
          ${link('/faq', 'Dúvidas', 'nav-link nav-faq')}
          ${link('/contato', 'Agendar conversa', 'button button-small button-primary')}
        </nav>
      </div>
    </header>`;
}

function footer() {
  return `
    <footer class="site-footer">
      <div class="footer-main">
        <div class="footer-brand">
          ${link('/', '<span class="brand-mark">AF</span><span class="brand-name">AF <b>Negócios Digitais</b></span>', 'brand-lockup')}
          <p>Construindo seu negócio com tecnologia, estratégia e parceria para e-commerce.</p>
          <div class="footer-social">${link(WA_URL, 'WhatsApp', 'text-link', 'target="_blank" rel="noreferrer"')}${link(`mailto:${EMAIL}`, 'E-mail', 'text-link')}</div>
        </div>
        <div class="footer-column"><h3>Soluções</h3>${serviceOrder.slice(0, 5).map((route) => link(route, servicePages[route].title, 'footer-link')).join('')}</div>
        <div class="footer-column"><h3>Empresa</h3>${link('/sobre', 'Sobre nós', 'footer-link')}${link('/processo', 'Como trabalhamos', 'footer-link')}${link('/cases', 'Histórias de clientes', 'footer-link')}${link('/faq', 'Perguntas frequentes', 'footer-link')}${link('/contato', 'Contato', 'footer-link')}</div>
        <div class="footer-column"><h3>Vamos conversar?</h3><a class="footer-link" href="tel:${PHONE_LINK}">${PHONE_DISPLAY}</a><a class="footer-link" href="mailto:${EMAIL}">${EMAIL}</a>${link('/contato', 'Fale com a equipe', 'footer-link footer-cta')}</div>
      </div>
      <div class="footer-bottom"><span>© ${new Date().getFullYear()} AF Negócios Digitais</span><span class="legal-links">${link('/privacidade', 'Privacidade', 'footer-link')}${link('/termos', 'Termos', 'footer-link')}${link('/lgpd', 'LGPD', 'footer-link')}</span><span class="legal-note">Páginas jurídicas aguardam conteúdo aprovado.</span></div>
    </footer>`;
}

function sectionHeading(eyebrow, title, description = '') {
  return `<div class="section-heading"><span class="eyebrow">${eyebrow}</span><h2>${title}</h2>${description ? `<p>${description}</p>` : ''}</div>`;
}

function serviceCard(route) {
  const item = servicePages[route];
  return `<article class="service-card">
    <div class="service-card-top"><span class="icon-tile">${icon(item.icon)}</span><span class="card-arrow">↗</span></div>
    <h3>${item.title}</h3><p>${item.subtitle}.</p>
    ${link(route, `Conheça a solução ${icon('arrow')}`, 'service-card-link')}
  </article>`;
}

function processCards(compact = false) {
  return `<div class="process-grid ${compact ? 'process-grid-compact' : ''}">${processSteps.map(([number, title, body]) => `<article class="process-card"><span class="process-number">${number}</span><h3>${title}</h3><p>${body}</p></article>`).join('')}</div>`;
}

function testimonialCards() {
  return `<div class="testimonial-grid">${testimonials.map((item) => `<article class="testimonial-card"><div class="quote-mark">“</div><blockquote>${item.quote}</blockquote><div class="testimonial-author"><span class="avatar-initials">${item.name.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span><span><b>${item.name}</b><small>${item.role}</small></span></div></article>`).join('')}</div>`;
}

function faqList(items = faqs) {
  return `<div class="faq-list">${items.map((item, index) => `<details class="faq-item" ${index === 0 ? 'open' : ''}><summary><span>${item.question}</span><span class="faq-plus">+</span></summary><div class="faq-answer"><p>${item.answer}</p></div></details>`).join('')}</div>`;
}

function homePage() {
  const serviceCards = serviceOrder.map(serviceCard).join('');
  return `
    <main id="conteudo">
      <section class="home-hero section-wrap">
        <div class="hero-copy">
          <span class="eyebrow eyebrow-pill"><span class="status-dot"></span> Parceira para seu próximo passo</span>
          <h1 id="main-title" tabindex="-1">Construindo<br /><em>seu negócio.</em></h1>
          <p class="hero-lead">Tecnologia e parceria para sua operação de e-commerce crescer com confiança.</p>
          <p class="hero-description">Estratégia, desenvolvimento e automação conectados ao que move seu negócio: uma operação digital melhor para seus clientes e para sua equipe.</p>
          <div class="hero-actions">${cta('Conte seu desafio')} ${link('/servicos/consultoria', `Conheça as soluções ${icon('arrow')}`, 'button button-quiet')}</div>
          <div class="hero-proof"><span>${icon('check')} Desde 2016</span><span>${icon('check')} Especialistas em e-commerce</span></div>
        </div>
        <div class="hero-visual">
          <img src="/manus-storage/afneg_visual_hero_326bf09a.png" alt="Empreendedora revisando a operação de sua loja digital em um estúdio acolhedor" />
          <div class="photo-caption"><span class="caption-mark">AF</span><span><b>Estratégia com proximidade</b><small>Do primeiro diagnóstico à evolução contínua</small></span></div>
          <div class="hero-note"><span class="hero-note-icon">${icon('leaf')}</span><span>Feito junto<br />com você</span></div>
        </div>
        <div class="hero-scroll-note"><span></span> Continue conhecendo</div>
      </section>

      <section class="trust-band"><div class="trust-inner"><span>O que conectamos</span><b>Estratégia</b><i></i><b>Tecnologia</b><i></i><b>Operação</b><i></i><b>Crescimento</b></div></section>

      <section class="section-wrap services-section" id="solucoes">
        ${sectionHeading('Como podemos ajudar', 'Soluções para construir <em>seu próximo capítulo.</em>', 'Apoiamos negócios digitais com serviços que se conectam à realidade da sua operação.')}
        <div class="service-grid">${serviceCards}</div>
        <div class="more-services-note">Quer começar pelo que mais importa agora? ${link('/contato', 'Vamos conversar', 'inline-link')}</div>
      </section>

      <section class="about-band">
        <div class="section-wrap about-band-inner">
          <div class="about-image"><img src="/manus-storage/afneg_visual_consultoria_55957b36.png" alt="Empreendedora e consultor analisando o negócio juntos" /><span class="image-stamp">Parceria<br />de verdade</span></div>
          <div class="about-copy"><span class="eyebrow">Um time ao lado do seu negócio</span><h2>Não entregamos só tecnologia. <em>Construímos com você.</em></h2><p>Desde 2016, a empresa trabalha para transformar negócios digitais com tecnologia e estratégia. Sob a marca AF Negócios Digitais, seguimos com o mesmo foco em e-commerce, relacionamento próximo e evolução contínua.</p><div class="values-list"><div>${icon('compass')}<span><b>Especialistas em e-commerce</b><small>Foco no comércio digital e nos desafios de quem vende online.</small></span></div><div>${icon('chart')}<span><b>Decisões orientadas por dados</b><small>Métricas e comportamento do cliente apoiam cada decisão.</small></span></div><div>${icon('heart')}<span><b>Parceria de longo prazo</b><small>Crescer junto com o cliente, não apenas concluir uma entrega.</small></span></div></div>${link('/sobre', `Conheça quem somos ${icon('arrow')}`, 'text-link text-link-underline')}</div>
        </div>
      </section>

      <section class="section-wrap process-section" id="processo">
        ${sectionHeading('Um caminho claro', 'Da primeira conversa à <em>evolução contínua.</em>', 'Um processo organizado para você saber o que acontece em cada etapa.')}
        ${processCards(true)}
        <div class="center-link">${link('/processo', `Veja como trabalhamos ${icon('arrow')}`, 'text-link text-link-underline')}</div>
      </section>

      <section class="case-band" id="historias">
        <div class="section-wrap">
          <div class="case-band-heading">${sectionHeading('O que dizem nossos clientes', 'Histórias de quem já <em>trabalhou com a AF.</em>', 'Depoimentos reproduzidos no site de referência.')}${link('/cases', `Ver os depoimentos ${icon('arrow')}`, 'text-link text-link-underline case-heading-link')}</div>
          <div class="testimonial-grid testimonial-grid-home">${testimonials.slice(0, 2).map((item) => `<article class="testimonial-card"><div class="quote-mark">“</div><blockquote>${item.quote}</blockquote><div class="testimonial-author"><span class="avatar-initials">${item.name.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span><span><b>${item.name}</b><small>${item.role}</small></span></div></article>`).join('')}</div>
        </div>
      </section>

      <section class="section-wrap faq-home-section">
        <div class="faq-home-intro">${sectionHeading('Dúvidas comuns', 'O que você quer <em>saber primeiro?</em>', 'Veja respostas sobre o trabalho, as plataformas e o acompanhamento.')}${link('/faq', `Todas as perguntas ${icon('arrow')}`, 'text-link text-link-underline')}</div>
        ${faqList(faqs.slice(0, 3))}
      </section>

      <section class="final-cta section-wrap"><div class="final-cta-panel"><div class="cta-ornament">AF</div><div><span class="eyebrow eyebrow-light">Seu próximo passo começa aqui</span><h2>Vamos construir <em>seu negócio?</em></h2><p>Conte o que você está planejando. Vamos entender sua operação e conversar sobre o caminho possível.</p></div><div class="final-cta-actions">${cta('Agendar uma conversa', 'button button-light')}<span>Resposta pelo WhatsApp ou e-mail</span></div></div></section>
    </main>`;
}

function servicePage(route, item) {
  const partnerBlock = item.partners ? `<div class="partner-ribbon"><span class="eyebrow">Experiência em plataformas</span><div>${item.partners.map((partner) => `<span class="partner-chip">${icon('check')}${partner}</span>`).join('')}</div></div>` : '';
  const relatedBlock = item.related ? `<section class="section-wrap related-section">${sectionHeading('Uma plataforma em destaque', 'Conheça o trabalho com <em>Nuvemshop.</em>')}<article class="service-card"><div class="service-card-top"><span class="icon-tile">${icon('store')}</span><span class="card-arrow">↗</span></div><h3>Nuvemshop</h3><p>Implementação, personalização e suporte para sua loja virtual.</p>${link('/servicos/desenvolvimento/nuvemshop', `Conheça a solução ${icon('arrow')}`, 'service-card-link')}</article></section>` : '';
  return `
    <main id="conteudo">
      <div class="breadcrumb section-wrap">${link('/', 'Início', 'breadcrumb-link')} <span>/</span> ${link('/#solucoes', 'Soluções', 'breadcrumb-link')} <span>/</span> <b>${item.title}</b></div>
      ${partnerBlock}
      <section class="service-hero section-wrap">
        <div class="service-hero-copy"><span class="eyebrow eyebrow-pill"><span class="status-dot"></span> ${item.eyebrow}</span><h1 id="main-title" tabindex="-1">${item.title.split(' ').slice(0, 2).join(' ')}<br /><em>${item.title.split(' ').slice(2).join(' ') || ''}</em></h1><h2>${item.subtitle}</h2><p>${item.description}</p><div class="hero-actions">${cta('Solicitar uma conversa')}<a class="button button-quiet" href="tel:${PHONE_LINK}">Ligar ${PHONE_DISPLAY}</a></div></div>
        <div class="service-hero-art"><div class="service-art-circle"></div><div class="service-art-icon">${icon(item.icon)}</div><span class="service-art-chip chip-one">${icon('check')} Estratégia</span><span class="service-art-chip chip-two">${icon('sparkles')} Evolução</span><span class="service-art-caption">Tecnologia que acompanha<br />o momento do seu negócio</span></div>
      </section>
      <section class="service-facts-band"><div class="section-wrap service-facts-inner"><div><span class="eyebrow">Com atenção a</span><b>Seu cenário</b><small>Objetivos e desafios reais</small></div><div><span class="eyebrow">Com trabalho em</span><b>Parceria</b><small>Planejamento e acompanhamento</small></div><div><span class="eyebrow">Com foco em</span><b>Evolução</b><small>Aprender, medir e ajustar</small></div></div></section>
      <section class="section-wrap service-detail-section"><div class="service-detail-intro">${sectionHeading('O que muda para sua operação', 'Uma solução pensada para <em>seu contexto.</em>', item.description)}</div><div class="benefit-columns"><div class="detail-card detail-card-green"><span class="eyebrow eyebrow-light">Benefícios</span><h3>O que você pode esperar</h3><ul class="check-list">${item.benefits.map((text) => `<li>${icon('check')}<span>${text}</span></li>`).join('')}</ul></div><div class="detail-card detail-card-cream"><span class="eyebrow">O que inclui</span><h3>Do planejamento ao acompanhamento</h3><ul class="check-list">${item.includes.map((text) => `<li>${icon('check')}<span>${text}</span></li>`).join('')}</ul></div></div></section>
      <section class="service-process-band"><div class="section-wrap">${sectionHeading('Como funciona', 'Etapas simples, conversa <em>transparente.</em>', 'O trabalho é organizado em etapas para que prioridades e próximos passos fiquem claros.')}${`<div class="service-steps">${item.process.map(([title, body], index) => `<article class="service-step"><span class="step-index">0${index + 1}</span><span class="step-marker">${icon(index === 0 ? 'compass' : index === 1 ? 'workflow' : 'check')}</span><h3>${title}</h3><p>${body}</p></article>`).join('')}</div>`}</div></section>
      ${relatedBlock}
      <section class="section-wrap service-cta-section"><div class="service-cta-card"><div><span class="eyebrow">Vamos conversar?</span><h2>Pronto para começar?</h2><p>Entre em contato e descubra como esta solução pode fazer sentido para sua operação.</p></div><div class="service-cta-actions">${cta('Solicitar orçamento')}<a href="mailto:${EMAIL}" class="text-link">Enviar e-mail ${icon('arrow')}</a><a href="tel:${PHONE_LINK}" class="text-link">Ligar ${PHONE_DISPLAY}</a></div></div></section>
      <section class="section-wrap more-solutions"><div class="more-solutions-heading">${sectionHeading('Veja também', 'Outras soluções para <em>sua operação.</em>')}</div><div class="more-solutions-links">${serviceOrder.filter((itemRoute) => itemRoute !== route).slice(0, 4).map((itemRoute) => link(itemRoute, `${icon(servicePages[itemRoute].icon)}<span>${servicePages[itemRoute].title}</span>${icon('arrow')}`, 'solution-list-link')).join('')}</div></section>
    </main>`;
}

function nuvemshopPage() {
  return `
    <main id="conteudo">
      <div class="breadcrumb section-wrap">${link('/', 'Início', 'breadcrumb-link')} <span>/</span> ${link('/servicos/desenvolvimento', 'Desenvolvimento', 'breadcrumb-link')} <span>/</span> <b>Nuvemshop</b></div>
      <section class="service-hero section-wrap nuvemshop-hero"><div class="service-hero-copy"><span class="eyebrow eyebrow-pill"><span class="status-dot"></span> Parceiro Silver Nuvemshop</span><h1 id="main-title" tabindex="-1">Sua loja na<br /><em>Nuvemshop.</em></h1><h2>Faça seu e-commerce crescer com uma plataforma preparada para vender online.</h2><p>A página de referência informa que a empresa é parceira Silver da Nuvemshop e oferece implementação especializada, customização e suporte para a loja virtual.</p><div class="hero-actions">${cta('Falar sobre minha loja')}<a class="button button-quiet" href="tel:${PHONE_LINK}">Ligar ${PHONE_DISPLAY}</a></div></div><div class="service-hero-art nuvemshop-art"><div class="service-art-circle"></div><div class="service-art-icon">${icon('store')}</div><span class="service-art-chip chip-one">${icon('check')} Implantação</span><span class="service-art-chip chip-two">${icon('sparkles')} Personalização</span><span class="service-art-caption">Loja virtual pronta<br />para acompanhar seu plano</span></div></section>
      <section class="service-facts-band"><div class="section-wrap service-facts-inner"><div><span class="eyebrow">Plataforma</span><b>Nuvemshop</b><small>Comércio digital</small></div><div><span class="eyebrow">Parceria</span><b>Silver</b><small>Conforme informação do site de referência</small></div><div><span class="eyebrow">Atuação</span><b>Implementar</b><small>Personalizar e integrar</small></div></div></section>
      <section class="section-wrap nuvemshop-about"><div class="nuvemshop-about-copy">${sectionHeading('Uma plataforma para vender online', 'Tecnologia com espaço <em>para crescer.</em>', 'A Nuvemshop é apresentada no site de referência como uma plataforma de e-commerce para negócios da América Latina.') }<p>A página original destaca facilidade de uso, escalabilidade e integrações como pontos importantes da plataforma. Informações estatísticas sobre a Nuvemshop não são reproduzidas aqui; os dados de mercado devem ser confirmados antes de uma publicação.</p></div><div class="nuvemshop-benefits"><article>${icon('window')}<h3>Facilidade de uso</h3><p>Uma interface para criar e gerenciar a loja sem exigir conhecimento técnico avançado.</p></article><article>${icon('chart')}<h3>Escalabilidade</h3><p>Uma estrutura que pode acompanhar mudanças de volume e as necessidades do negócio.</p></article><article>${icon('plug')}<h3>Integrações</h3><p>Aplicativos e integrações para ampliar recursos e conectar a operação.</p></article></div></section>
      <section class="service-process-band"><div class="section-wrap">${sectionHeading('Como podemos apoiar', 'Da implementação ao <em>suporte contínuo.</em>') }<div class="nuvemshop-services-grid">${[['Implementação completa','Setup inicial, configuração de produtos, pagamento e frete.','store'],['Customização avançada','Design personalizado, funcionalidades, integrações e otimização para conversão.','sparkles'],['Migração de plataforma','Migração de produtos e clientes, preservação de SEO e planejamento da transição.','workflow'],['Suporte contínuo','Atualizações, acompanhamento de performance, suporte técnico e consultoria.','message']].map(([title,body,ico]) => `<article class="nuvemshop-service-card"><span class="icon-tile">${icon(ico)}</span><h3>${title}</h3><p>${body}</p></article>`).join('')}</div></div></section>
      <section class="section-wrap service-cta-section"><div class="service-cta-card"><div><span class="eyebrow">Parceiro Silver Nuvemshop</span><h2>Pronto para criar ou evoluir sua loja?</h2><p>Converse com a AF Negócios Digitais sobre implementação, customização e integrações.</p></div><div class="service-cta-actions">${cta('Falar sobre Nuvemshop')}<a href="${WA_URL}" class="text-link" target="_blank" rel="noreferrer">WhatsApp ${icon('arrow')}</a><a href="mailto:${EMAIL}" class="text-link">Enviar e-mail ${icon('arrow')}</a></div></div></section>
    </main>`;
}

function aboutPage() {
  return `<main id="conteudo"><section class="page-hero section-wrap"><div class="page-hero-copy"><span class="eyebrow eyebrow-pill"><span class="status-dot"></span> Quem somos</span><h1 id="main-title" tabindex="-1">Tecnologia com <em>conversa de verdade.</em></h1><p class="hero-lead">Somos especialistas em e-commerce e trabalhamos para transformar negócios com tecnologia e estratégia.</p><p>O site de referência apresenta uma empresa focada em comércio digital desde 2016. Nesta nova direção, a marca passa a ser AF Negócios Digitais — mantendo a experiência, a proximidade e o compromisso com evolução contínua.</p>${cta('Vamos nos conhecer')}</div><div class="page-hero-image"><img src="/manus-storage/afneg_visual_consultoria_55957b36.png" alt="Empreendedora e consultor trabalhando juntos" /><span class="photo-caption"><span class="caption-mark">AF</span><span><b>Próximos do negócio</b><small>Estratégia com pessoas no centro</small></span></span></div></section><section class="section-wrap value-section">${sectionHeading('O que nos guia', 'Uma parceria construída <em>em conjunto.</em>') }<div class="value-grid"><article>${icon('compass')}<h3>Especialistas em e-commerce</h3><p>Foco no comércio digital, nas plataformas e nos desafios de quem opera uma loja virtual.</p></article><article>${icon('chart')}<h3>Método orientado a dados</h3><p>Decisões apoiadas por métricas de conversão, comportamento do cliente e contexto do segmento.</p></article><article>${icon('sparkles')}<h3>IA aplicada à realidade</h3><p>Uso prático de inteligência artificial para resolver problemas concretos da operação.</p></article><article>${icon('heart')}<h3>Parceria de longo prazo</h3><p>Relações duradouras e evolução conjunta, para além da entrega pontual.</p></article></div></section><section class="about-band"><div class="section-wrap about-band-inner about-band-reverse"><div class="about-copy">${sectionHeading('Nosso compromisso', 'Crescer junto com <em>seu negócio.</em>', 'Tecnologia só faz sentido quando resolve uma necessidade real.') }<p>Por isso, começamos entendendo o cenário, definimos prioridades com você e acompanhamos o que acontece depois da entrega. O objetivo é que cada iniciativa tenha contexto, propósito e um caminho claro de evolução.</p>${link('/processo', `Conheça nosso processo ${icon('arrow')}`, 'text-link text-link-underline')}</div><div class="about-image"><img src="/manus-storage/afneg_visual_operacao_a97dbf3b.png" alt="Empreendedor preparando um pedido da loja online" /></div></div></section><section class="section-wrap centered-cta">${sectionHeading('Vamos conversar', 'Conte para nós o que você está <em>construindo.</em>', 'Uma conversa inicial ajuda a entender sua operação e o próximo passo possível.')} ${cta('Agendar conversa')}</section></main>`;
}

function processPage() {
  return `<main id="conteudo"><section class="page-hero page-hero-simple section-wrap"><div class="page-hero-copy"><span class="eyebrow eyebrow-pill"><span class="status-dot"></span> Como trabalhamos</span><h1 id="main-title" tabindex="-1">Clareza do primeiro passo à <em>evolução contínua.</em></h1><p class="hero-lead">Um processo claro e transparente para que você saiba o que esperar em cada fase do projeto.</p>${cta('Conversar sobre meu projeto')}</div><div class="process-hero-note"><span class="big-number">04</span><span>etapas que organizam<br />o trabalho em parceria</span></div></section><section class="section-wrap process-page-section">${sectionHeading('O caminho do projeto', 'Estratégia, execução e <em>acompanhamento.</em>', 'Cada etapa considera as necessidades da operação e as prioridades combinadas.') }${processCards()}<div class="process-note-box"><span class="icon-tile">${icon('message')}</span><p>O escopo de cada serviço muda de acordo com a necessidade. As etapas e os prazos são alinhados durante a conversa inicial.</p></div></section><section class="about-band"><div class="section-wrap about-band-inner"><div class="about-image"><img src="/manus-storage/afneg_visual_consultoria_55957b36.png" alt="Discussão de estratégia em equipe" /></div><div class="about-copy"><span class="eyebrow">Transparência em cada etapa</span><h2>Você sabe onde estamos e <em>o que vem depois.</em></h2><p>O processo combina diagnóstico, plano de ação, execução e revisão do que foi realizado. O site de referência descreve relatórios periódicos, comunicação transparente e otimizações constantes.</p>${cta('Falar com um especialista')}</div></div></section></main>`;
}

function casesPage() {
  return `<main id="conteudo"><section class="page-hero page-hero-simple section-wrap"><div class="page-hero-copy"><span class="eyebrow eyebrow-pill"><span class="status-dot"></span> Histórias de clientes</span><h1 id="main-title" tabindex="-1">Vozes de quem já <em>trabalhou com a AF.</em></h1><p class="hero-lead">A página de referência apresenta depoimentos de clientes sobre desenvolvimento, automação e integração.</p><p>Os relatos abaixo foram resumidos a partir dos depoimentos publicados no site de referência. Os números e a autorização de divulgação devem ser confirmados antes da publicação. Como a referência não traz estudos de caso completos, não acrescentamos contexto além do texto publicado.</p>${cta('Falar sobre um projeto parecido')}</div><div class="case-hero-mark"><span>AF</span><i></i><small>Histórias construídas<br />em parceria</small></div></section><section class="case-band case-page-band"><div class="section-wrap">${sectionHeading('Depoimentos publicados', 'Experiências compartilhadas <em>por clientes.</em>', 'Os resultados quantitativos abaixo foram publicados como parte dos depoimentos na referência e devem ser confirmados antes de uso promocional.')}${testimonialCards()}</div></section><section class="section-wrap case-note-section"><div class="case-note"><span class="eyebrow">Sobre este conteúdo</span><p>Para transformar estes relatos em estudos de caso completos, será necessário acrescentar, com aprovação, o contexto de cada projeto, o desafio, a solução implantada e a autorização dos clientes para divulgar os dados.</p></div>${cta('Quero conversar sobre meu desafio')}</section></main>`;
}

function contactPage() {
  return `<main id="conteudo"><section class="contact-hero section-wrap"><div class="contact-copy"><span class="eyebrow eyebrow-pill"><span class="status-dot"></span> Fale com a gente</span><h1 id="main-title" tabindex="-1">Vamos conversar sobre <em>seu próximo passo.</em></h1><p class="hero-lead">Conte um pouco sobre o que você está construindo. A equipe pode ajudar a organizar a conversa e entender suas prioridades.</p><div class="contact-options"><a href="tel:${PHONE_LINK}" class="contact-option">${icon('message')}<span><small>WhatsApp ou telefone</small><b>${PHONE_DISPLAY}</b></span>${icon('arrow')}</a><a href="mailto:${EMAIL}" class="contact-option">${icon('window')}<span><small>E-mail</small><b>${EMAIL}</b></span>${icon('arrow')}</a></div></div><div class="contact-form-card"><span class="eyebrow">Um primeiro contato</span><h2>Conte sobre seu projeto</h2><p>Preencha os campos e seu aplicativo de e-mail abrirá uma mensagem pronta para enviar.</p><form id="contact-form"><label for="contact-name">Seu nome</label><input id="contact-name" name="name" autocomplete="name" required placeholder="Como podemos chamar você?" /><label for="contact-email">Seu e-mail</label><input id="contact-email" type="email" name="email" autocomplete="email" required placeholder="voce@empresa.com" /><label for="contact-message">O que você precisa?</label><textarea id="contact-message" name="message" rows="4" required placeholder="Conte brevemente sobre sua operação ou desafio"></textarea><button class="button button-primary" type="submit">Preparar mensagem ${icon('arrow')}</button><small class="form-note">Este protótipo não armazena nem envia dados. A mensagem será preparada no seu aplicativo de e-mail.</small></form></div></section><section class="contact-bottom-band"><div class="section-wrap contact-bottom-inner"><span class="eyebrow">Prefere falar agora?</span><h2>Estamos a uma mensagem de distância.</h2><a href="${WA_URL}" class="button button-light" target="_blank" rel="noreferrer">Abrir WhatsApp ${icon('arrow')}</a></div></section></main>`;
}

function faqPage() {
  return `<main id="conteudo"><section class="page-hero page-hero-simple section-wrap"><div class="page-hero-copy"><span class="eyebrow eyebrow-pill"><span class="status-dot"></span> Perguntas frequentes</span><h1 id="main-title" tabindex="-1">Respostas para começar <em>com clareza.</em></h1><p class="hero-lead">Informações sobre prazos, formatos de trabalho, plataformas e suporte, conforme o conteúdo do site de referência.</p>${cta('Falar com um especialista')}</div><div class="faq-hero-mark">${icon('message')}<span>Tem uma pergunta<br />que não está aqui?</span></div></section><section class="section-wrap faq-page-section">${sectionHeading('Dúvidas comuns', 'Perguntas que você <em>pode ter.</em>')}${faqList()}<div class="faq-contact-box"><div><span class="eyebrow">Ainda quer conversar?</span><h3>Vamos entender juntos.</h3><p>A equipe pode ajudar a esclarecer o que faz mais sentido para sua operação.</p></div>${cta('Falar com especialista')}</div></section></main>`;
}

function legalPage(path) {
  const entries = {
    '/privacidade': ['Política de Privacidade', 'O conteúdo desta política não estava disponível nas páginas de referência consultadas.'],
    '/termos': ['Termos de Uso', 'O texto dos termos não estava disponível nas páginas de referência consultadas.'],
    '/lgpd': ['Informações sobre LGPD', 'O conteúdo específico de LGPD não estava disponível nas páginas de referência consultadas.'],
  };
  const [title, message] = entries[path];
  return `<main id="conteudo"><section class="legal-page section-wrap"><span class="eyebrow eyebrow-pill">Informação pendente</span><h1 id="main-title" tabindex="-1">${title}</h1><div class="legal-warning">${icon('message')}<div><h2>Texto aprovado necessário</h2><p>${message} Esta página é apenas um marcador de protótipo e não constitui uma política ou orientação jurídica. O conteúdo final deve ser fornecido e aprovado antes da publicação.</p></div></div>${link('/', `Voltar para a página inicial ${icon('arrow')}`, 'text-link text-link-underline')}</section></main>`;
}

const pageTitles = {
  '/': 'Início',
  '/sobre': 'Sobre',
  '/processo': 'Como trabalhamos',
  '/cases': 'Histórias de clientes',
  '/contato': 'Contato',
  '/faq': 'Perguntas frequentes',
  '/privacidade': 'Política de Privacidade',
  '/termos': 'Termos de Uso',
  '/lgpd': 'LGPD',
};

function normalizePath(pathname) {
  if (pathname.length > 1 && pathname.endsWith('/')) return pathname.slice(0, -1);
  return pathname;
}

function render() {
  const path = normalizePath(window.location.pathname);
  let content;
  if (path === '/') content = homePage();
  else if (servicePages[path]) content = servicePage(path, servicePages[path]);
  else if (path === '/servicos/desenvolvimento/nuvemshop') content = nuvemshopPage();
  else if (path === '/sobre') content = aboutPage();
  else if (path === '/processo') content = processPage();
  else if (path === '/cases') content = casesPage();
  else if (path === '/contato') content = contactPage();
  else if (path === '/faq') content = faqPage();
  else if (['/privacidade', '/termos', '/lgpd'].includes(path)) content = legalPage(path);
  else content = `<main id="conteudo"><section class="legal-page section-wrap"><h1 id="main-title">Página não encontrada</h1><p>Não encontramos esta página no protótipo.</p>${link('/', `Voltar ao início ${icon('arrow')}`, 'text-link text-link-underline')}</section></main>`;

  document.title = `${pageTitles[path] || servicePages[path]?.title || (path === '/servicos/desenvolvimento/nuvemshop' ? 'Nuvemshop' : 'Página não encontrada')} | AF Negócios Digitais`;
  document.getElementById('app').innerHTML = `${header()}${content}${footer()}<a class="whatsapp-float" href="${WA_URL}" target="_blank" rel="noreferrer" aria-label="Falar com a AF Negócios Digitais pelo WhatsApp">${icon('message')}<span>Vamos conversar</span></a>`;
  bindInteractions();
}

function bindInteractions() {
  const toggle = document.querySelector('[data-menu-toggle]');
  const nav = document.querySelector('[data-main-nav]');
  toggle?.addEventListener('click', () => {
    const open = nav.classList.toggle('is-open');
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Fechar menu' : 'Abrir menu');
  });

  document.querySelectorAll('.main-nav a[data-link]').forEach((anchor) => {
    anchor.addEventListener('click', () => {
      document.querySelector('.nav-services')?.removeAttribute('open');
      nav?.classList.remove('is-open');
      toggle?.setAttribute('aria-expanded', 'false');
      toggle?.setAttribute('aria-label', 'Abrir menu');
    });
  });

  const form = document.getElementById('contact-form');
  form?.addEventListener('submit', (event) => {
    event.preventDefault();
    const data = new FormData(form);
    const subject = encodeURIComponent(`Contato pelo site — ${data.get('name')}`);
    const body = encodeURIComponent(`Nome: ${data.get('name')}\nE-mail: ${data.get('email')}\n\n${data.get('message')}`);
    window.location.href = `mailto:${EMAIL}?subject=${subject}&body=${body}`;
  });
}

document.addEventListener('click', (event) => {
  const anchor = event.target.closest('a[data-link]');
  if (!anchor || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
  const destination = new URL(anchor.href, window.location.origin);
  if (destination.origin !== window.location.origin) return;
  event.preventDefault();
  const next = `${destination.pathname}${destination.search}${destination.hash}`;
  if (`${window.location.pathname}${window.location.search}${window.location.hash}` !== next) history.pushState({}, '', next);
  render();
  if (destination.hash) {
    requestAnimationFrame(() => document.getElementById(decodeURIComponent(destination.hash.slice(1)))?.scrollIntoView({ behavior: 'smooth' }));
  } else {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    document.getElementById('main-title')?.focus({ preventScroll: true });
  }
});

window.addEventListener('popstate', render);
render();
