# Código-fonte incluído

A cópia reúne os arquivos usados pelo protótipo em formato leve, sem dependências de terceiros. `app.js` contém renderização, conteúdo e rotas; `styles.css`, o design system aplicado; `index.html`, a estrutura-base; `manus-routes.json`, a lista de 19 rotas; `server.js` e `package.json`, o servidor local; `app.config.ts`, a configuração da marca; `favicon.svg`, o símbolo da aba.

Para iniciar com Node.js, execute `node server.js` nesta pasta e abra `http://localhost:3000`. Para substituir os caminhos de imagens `/manus-storage/` fora do ambiente Webdev, copie os arquivos JPEG de `../assets/images/otimizadas/` para uma pasta pública da aplicação e ajuste os `src` correspondentes no app.js.

Nenhum arquivo de ambiente, token, chave ou credencial está incluído.
