# AF Negócios Digitais
## Design system e inventário do protótipo

**Versão:** 1.0 · **Data:** 15 nov. 2026 · **Direção escolhida:** Mockup 2, consultivo/editorial, páginas verticais longas.

Este guia descreve a interface que foi efetivamente construída no protótipo navegável. O ZIP também contém os arquivos originais das três imagens, ícones vetoriais SVG, código-fonte e capturas completas das 19 páginas em desktop, além de exemplos mobile.

> **Posicionamento visual:** proximidade humana e clareza de negócio, com a tecnologia apresentada como meio para construir e evoluir operações de e-commerce. A assinatura de voz é “Construindo seu negócio”.

## 1. Direção de arte

A linguagem visual selecionada combina editorial contemporâneo com consultoria digital acolhedora. Ela evita a estética fria de software corporativo: usa fotografias de contexto realista, títulos serifados com contraste, áreas vazias generosas, paleta orgânica e detalhes gráficos delicados. O resultado deve transmitir parceria, competência e pragmatismo.

**Princípios.** Pessoas antes de ferramentas; informação organizada em blocos escaneáveis; chamadas para ação próximas do contexto; credibilidade sem promessas absolutas; mesmo ritmo de leitura em telas estreitas.

**Motivos visuais.** Monograma AF, arcos/contornos orgânicos finos e selos circulares; cartões marfim de borda sutil; alternância entre faixas de fundo creme e verde profundo; acento terracota em links, números e ícones.

## 2. Paleta de cores

Os nomes abaixo espelham variáveis CSS existentes em `codigo-fonte/styles.css`. Os valores RGBA descrevem as linhas/sombras exatamente; as cores sólidas são tokens primários.

| Token CSS | Valor | Aplicação recomendada |
|---|---|---|
| `--paper` | `#F7F4EC` | Fundo geral marfim e superfícies claras. |
| `--paper-2` | `#EEE9DC` | Variação quente de fundo. |
| `--cream` | `#FCFAF5` | Cartões, menus e formulário. |
| `--green` | `#254C3A` | Cor de marca, botões e faixas de conteúdo. |
| `--green-deep` | `#18392D` | Títulos e áreas de contraste alto. |
| `--green-soft` | `#DFE8DF` | Fundos de ícones e caixas de apoio. |
| `--terracotta` | `#C77658` | Acento proprietário, links, estados de destaque. |
| `--terracotta-soft` | `#F0DFD5` | Fundo suave de ícones/alertas. |
| `--ink` | `#24362C` | Texto principal. |
| `--muted` | `#69746B` | Texto auxiliar e descrições. |
| `--white` | `#FFFEFA` | Texto/superfície clara sobre verde. |
| Linha padrão | `rgba(37, 76, 58, .15)` | Bordas finas e divisórias. |
| Terracota claro | `#DDA182` | Destaques sobre verde escuro. |

**Hierarquia cromática.** Marfim ocupa os maiores planos; verde profundo estabelece estrutura, marca e contraste; terracota aparece como acento, não como área dominante. Mantenha contraste legível em texto pequeno e não use o verde claro como cor de texto sobre fundo claro.

## 3. Tipografia

- **Títulos e destaques:** Playfair Display, pesos 500/600/700, itálico 500/600. Aplicar em H1/H2, títulos de cards, números e trechos destacados.
- **Interface e texto corrente:** DM Sans, pesos 400/500/600/700. Aplicar em navegação, parágrafos, labels, botões e microcopy.
- **Fallbacks definidos:** Georgia para a família serifada; Avenir Next, Avenir e `sans-serif` para interface.
- **Origem:** o CSS solicita Playfair Display e DM Sans por Google Fonts; sem rede, os fallbacks assumem. Não há arquivos de fonte locais no pacote.

| Nível | Regra visual implementada (desktop) | Observação |
|---|---|---|
| H1 da home | `clamp(58px, 6.8vw, 86px)`, peso 500, line-height `.99`, tracking `-.055em` | Composição em duas linhas. |
| H1 interno | `clamp(50–58px, responsivo, 70–77px)` | Títulos serifados, geralmente com trecho itálico terracota. |
| H2 de seção | `clamp(36px, 4vw, 53px)`, peso 500, line-height `1.13` | Varia conforme seção. |
| Corpo | Base `16px / 1.65`; descrições em geral `12–14px / 1.7–1.85` | DM Sans. |
| Eyebrow | `11px`, bold, caixa alta, tracking `.14em` | Em pílula quando identifica hero. |
| Botões/nav | `12–13px`, peso 600–700 | Labels curtos e diretos. |

## 4. Layout, espaçamento e formas

- **Largura principal:** conteúdo máximo `1160px`, margens laterais fluidas. O cabeçalho pode chegar a `1320px`.
- **Raio-base de cards:** `18px`; menu/cartões especiais variam de `12px` a `26px`; botões/pílulas são arredondados ao máximo.
- **Sombra de referência:** `0 20px 55px rgba(31, 55, 43, .10)`; uso concentrado em fotografia, menu e interação de cards.
- **Ritmo vertical:** páginas longas, com hero generoso, faixas de confiança, serviços, conteúdo editorial, processo, prova social/FAQ e CTA de fechamento. Seções desktop normalmente recebem ~90–105px de respiro vertical e reduzem em mobile.
- **Composição e fotografia:** alternar texto, fotos em arco e faixas marfim/verde/bege; usar grades quando ajudarem a comparar ofertas (três colunas de serviços na home desktop). Imagens recebem cantos superiores em arco/cápsula, cantos inferiores arredondados e contornos orgânicos discretos.

**Escala sugerida para manutenção (não token atual):** 4, 8, 12, 16, 24, 32, 48, 64, 80 e 96 px.

## 5. Componentes e estados

| Componente | Especificação visual/comportamental |
|---|---|
| Cabeçalho sticky | Marfim translúcido, divisor inferior e blur; logo à esquerda; navegação e CTA à direita. |
| Menu “Soluções” | `details/summary` nativo; mega-menu com bloco verde editorial e links em duas colunas. Em celular vira lista expansível. |
| Botão primário | Verde, texto claro, pílula, ícone de seta; leve elevação no hover. |
| Botão secundário | Transparente com contorno verde discreto. A versão clara é usada sobre a faixa terracota final. |
| Hero | Eyebrow/pílula, H1 editorial, frase de apoio, descrição, CTAs e sinais de confiança. Home usa foto e cartão de legenda. |
| Cartão de serviço | Fundo creme, borda verde suave, tile de ícone, título serifado, descrição e link terracota. Hover eleva discretamente. |
| Faixa de processo | Etapas numeradas em serif itálico com divisória superior; quatro etapas na visão geral. |
| Depoimento | Cartão verde escuro, aspas terracota, texto serifado e avatar por iniciais. Identificar como conteúdo da referência. |
| FAQ | Acordeão `details/summary`, separadores finos e controle circular `+`. Primeira pergunta aberta no carregamento. |
| CTA de fechamento | Painel terracota, ornamento de monograma com baixa opacidade, título branco e botão claro. |
| Formulário de contato | Campos com contorno suave e foco terracota. No protótipo não envia nem armazena: prepara uma mensagem `mailto:` no dispositivo. |
| Rodapé | Fundo verde profundo, marca, links agrupados, contatos e links legais; observação de que conteúdo legal está pendente. |
| WhatsApp flutuante | Pílula fixa verde com ícone; pode ficar oculto em captura de página longa por ser elemento `fixed`. |

**Interação e acessibilidade.** Navegação interna via rotas do protótipo, CTA telefônico/e-mail/WhatsApp, botão de menu mobile com estado `aria-expanded`, pular para o conteúdo, links com foco visível e suporte à preferência `prefers-reduced-motion`. Não há animações essenciais; transições curtas são decorativas.

## 6. Ícones vetoriais

O protótipo usa **15 ícones de linha originais em SVG inline**, extraídos fielmente do objeto `icons` de `app.js` e incluídos individualmente em `assets/icons/`. O canvas é `24 × 24`; sem preenchimento, traço `currentColor`, largura `1.6`, terminais e junções arredondados. Os arquivos têm fundo transparente e herdam a cor do contexto.

| Arquivo / nome | Uso semântico previsto |
|---|---|
| `compass.svg` | Consultoria, diagnóstico e direção. |
| `store.svg` | E-commerce, loja e Nuvemshop. |
| `sparkles.svg` | Inteligência artificial, ideias e melhoria. |
| `chart.svg` | BI, métricas e crescimento. |
| `workflow.svg` | Automação, processo e migração. |
| `window.svg` | Sites, interface e plataforma. |
| `megaphone.svg` | Tráfego pago e divulgação. |
| `database.svg` | ERP, dados e gestão. |
| `plug.svg` | Integrações e conectividade. |
| `arrow.svg` | Navegação, CTA e continuidade. |
| `check.svg` | Benefício, confirmação e lista. |
| `leaf.svg` | Crescimento orgânico e proximidade. |
| `hand.svg` | Parceria e cuidado. |
| `heart.svg` | Relação humana e confiança. |
| `message.svg` | Conversa, atendimento e suporte. |

A pasta também contém `sprite.svg` para reutilização como `<svg><use href="sprite.svg#compass"></use></svg>` e `index.html` como catálogo navegável. Símbolos tipográficos como chevron e `+` do FAQ não fazem parte do conjunto SVG.

## 7. Imagens do protótipo

As três fotografias editoriais foram criadas para este protótipo; são ilustrativas, não representam clientes ou integrantes reais da AF. Os PNGs originais de **2176 × 1632 px** estão guardados em `assets/images/originais/`. As versões JPEG em `assets/images/otimizadas/` são derivações para web/PDF com compressão, mantendo a composição. Use os originais como fonte e os JPEGs quando peso de arquivo importar.

| Arquivo | Uso registrado no layout | Tratamento no site |
|---|---|---|
| `hero-home.png` | Hero da home. | Enquadramento alto, composição em arco; CSS `object-position: 54% 45%`. |
| `consultoria-parceria.png` | Bloco institucional da home, Sobre e Processo. | Recorte vertical arredondado para narrativa de colaboração. |
| `operacao-envios.png` | Bloco de operação na página Sobre. | Fotografia editorial de preparação de pedidos/e-commerce. |
| `favicon.svg` | Favicon/assinatura de aba; símbolo geométrico AF. | Verde de marca, forma marfim e haste terracota. |

### Amostras das imagens editoriais

| Hero da home | Consultoria | Operação |
|---|---|---|
| ![Empreendedora usando uma loja digital](../assets/images/otimizadas/hero-home.jpg) | ![Parceria em um pequeno negócio](../assets/images/otimizadas/consultoria-parceria.jpg) | ![Preparação de pedidos de e-commerce](../assets/images/otimizadas/operacao-envios.jpg) |

## 8. Responsividade

| Largura | Comportamento presente no CSS |
|---|---|
| `> 1050px` | Navegação horizontal; grids completos; conteúdo até `1160px`. |
| `≤ 1050px` | Espaçamentos e navegação compactados; rodapé reconfigurado. |
| `≤ 780px` | Menu hambúrguer; hero e conteúdo em coluna; cards em duas colunas quando cabem; processo em duas colunas; botões CTA empilháveis. |
| `≤ 430px` | Serviços, processo e valores passam a uma coluna; opções/soluções refluem; tipografia e margens compactadas. |

Capturas completas em largura de **1440 px** cobrem as 19 rotas. Exemplos mobile foram capturados a **390 px** em sete páginas representativas (a captura de home registra área útil de 349 px no PNG em página longa). Os arquivos estão em `telas/desktop/` e `telas/mobile/`. O catálogo de telas está em `telas/index.html`; o inventário de rotas também foi copiado para `documento/manifesto-de-rotas.json`.

## 9. Inventário de páginas

| Grupo | Rota | Arquivo desktop |
|---|---|---|
| Principal | `/` — Início | `home-desktop.png` |
| Serviços | `/servicos/consultoria` — Consultoria em e-commerce | `consultoria-desktop.png` |
| Serviços | `/servicos/desenvolvimento` — Desenvolvimento de e-commerce | `desenvolvimento-desktop.png` |
| Serviços | `/servicos/desenvolvimento/nuvemshop` — Nuvemshop | `nuvemshop-desktop.png` |
| Serviços | `/servicos/ia` — Sistemas com IA | `ia-desktop.png` |
| Serviços | `/servicos/bi` — Business Intelligence | `bi-desktop.png` |
| Serviços | `/servicos/automacao` — Automação de processos | `automacao-desktop.png` |
| Serviços | `/servicos/sites` — Sites institucionais | `sites-desktop.png` |
| Serviços | `/servicos/trafego` — Tráfego pago | `trafego-desktop.png` |
| Serviços | `/servicos/erp` — Implementação de ERPs | `erp-desktop.png` |
| Serviços | `/servicos/integracao` — Integração de sistemas | `integracao-desktop.png` |
| Institucional | `/sobre` — Sobre | `sobre-desktop.png` |
| Institucional | `/processo` — Processo | `processo-desktop.png` |
| Institucional | `/cases` — Cases/depoimentos | `cases-desktop.png` |
| Institucional | `/contato` — Contato | `contato-desktop.png` |
| Institucional | `/faq` — Perguntas frequentes | `faq-desktop.png` |
| Legal (marcador) | `/privacidade` — Privacidade | `privacidade-desktop.png` |
| Legal (marcador) | `/termos` — Termos | `termos-desktop.png` |
| Legal (marcador) | `/lgpd` — LGPD | `lgpd-desktop.png` |

As páginas legais sinalizam explicitamente que exigem conteúdo revisado/aprovado; não são aconselhamento nem política jurídica final. Os depoimentos em Cases foram resumidos a partir do site de referência e requerem confirmação de nomes, métricas e autorização antes de eventual publicação.

## 10. Arquivos-fonte incluídos

- `codigo-fonte/app.js`: dados das páginas, catálogo de ícones inline, renderização, navegação e pequenas interações.
- `codigo-fonte/styles.css`: identidade, componentes, estados e media queries completas.
- `codigo-fonte/index.html`: estrutura base do documento.
- `codigo-fonte/manus-routes.json`: manifesto das 19 páginas.
- `codigo-fonte/server.js` e `codigo-fonte/package.json`: servidor leve para executar o protótipo localmente.
- `codigo-fonte/app.config.ts`: configuração do ícone do projeto.
- `assets/icons/`: conjunto SVG e catálogo navegável.
- `assets/images/`: imagens originais e versões otimizadas.
- `telas/`: capturas PNG de páginas completas.

## 11. Execução local

É possível recriar o preview com Node.js instalado: na pasta `codigo-fonte`, execute `node server.js` e abra `http://localhost:3000`. As imagens em produção do protótipo são servidas pelo armazenamento do projeto; o pacote fornece os PNGs locais como referência e fonte. Para usar as imagens ao executar fora do preview gerenciado, copiar as imagens otimizadas para uma pasta pública e atualizar os três `src` de `/manus-storage/` em `app.js`.

## 12. Licenciamento e conteúdo

Código, composição e ícones deste pacote correspondem ao protótipo. As três imagens são ilustrações geradas por IA para este trabalho, não fotos documentais de pessoas/empresas específicas. As fontes Playfair Display e DM Sans são carregadas do serviço Google Fonts pelo protótipo; conferir licença e distribuição de arquivos de fonte se elas forem auto-hospedadas. Informações comerciais, logos de plataformas, depoimentos e políticas legais devem ser validados pelos responsáveis da marca antes de um lançamento público.
