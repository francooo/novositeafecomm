# Pacote Design System — AF Negócios Digitais

Este arquivo ZIP reúne as especificações do design system aplicado ao protótipo navegável AF Negócios Digitais, os mockups completos das páginas, as imagens editoriais usadas, os SVGs de ícones e a cópia do código-fonte relevante.

## Comece por aqui

1. Leia [`documento/Design_System_AF_Negocios_Digitais.pdf`](documento/Design_System_AF_Negocios_Digitais.pdf) para a documentação diagramada ou [`documento/Design_System_AF_Negocios_Digitais.md`](documento/Design_System_AF_Negocios_Digitais.md) para a versão editável.
2. Abra [`telas/index.html`](telas/index.html) em um navegador para navegar pelas miniaturas. Cada miniatura abre a tela PNG completa em alta resolução.
3. Abra [`assets/icons/index.html`](assets/icons/index.html) para visualizar os ícones SVG individualmente.
4. Consulte `assets/images/originais/` para os arquivos-fonte das imagens e `assets/images/otimizadas/` para as versões JPEG compactas.
5. Os arquivos do protótipo estão em `codigo-fonte/`.

## O que está incluído

- **Design system:** identidade e voz, tokens de cor, tipografia, layout, formas, padrões, responsividade, comportamento e componentes.
- **19 capturas desktop:** todas as páginas do protótipo em 1440 px de largura, em páginas completas.
- **7 capturas mobile:** exemplos representativos em 390 px de largura, também em página completa.
- **3 imagens editoriais:** PNGs originais 2176 × 1632 px e JPEGs otimizados para web/PDF.
- **15 ícones SVG:** extraídos do protótipo, em arquivos individuais, mais sprite e catálogo HTML.
- **Código:** app.js, styles.css, index.html, manifesto de rotas, servidor Node, package.json, favicon e configuração do projeto.

## Nota de escopo

É um pacote de referência do protótipo — não um projeto final de produção. O conteúdo jurídico precisa de aprovação; depoimentos e números precisam de confirmação/autorização; as imagens são ilustrações geradas para o protótipo. Fontes são obtidas do Google Fonts no protótipo e têm fallbacks documentados.
