# Assets

`images/originais/` preserva os PNGs de origem sem alteração; `images/otimizadas/` contém conversões JPEG de qualidade 90 para usos leves. `icons/` contém os 15 ícones extraídos da implementação: arquivos SVG independentes, sprite e catálogo visual `index.html`. Os SVGs individuais usam traço verde de marca para visualização fora do site; o sprite herda `currentColor`.

As três fotografias editoriais são imagens geradas para o protótipo, não representam clientes reais. Favicon e monograma estão incluídos em SVG.
